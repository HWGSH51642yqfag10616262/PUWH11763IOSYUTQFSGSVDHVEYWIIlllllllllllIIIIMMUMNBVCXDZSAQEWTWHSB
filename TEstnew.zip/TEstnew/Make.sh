make package

mv /var/mobile/NewVirus/.theos/_/Library/MobileSubstrate/DynamicLibraries/Virus.dylib /var/containers/Bundle/Application/81C6BD81-4C77-4911-B311-A04A1075E9FD/ShadowTrackerExtra.app/Frameworks/App.framework/App